const jwt = require('jsonwebtoken'); // Import jwt module only once
const User = require('../models/authModel');

const authentication = (req, res, next) => {
    const token = req.cookies.jwt;

    if (token) {
        jwt.verify(token, 'nodejsproject', (err, tokens) => {
            if (err) {
                console.log(err.message);
                res.redirect('/login');
            } else {
                console.log(tokens);
                next();
            }
        });
    } else {
        res.redirect('/login');
    }
};

const Users = async (req, res, next) => {
    const token = req.cookies.jwt;

    if (token) {
        jwt.verify(token, 'nodejsproject', async (err, tokens) => {
            if (err) {
                console.log(err.message);
                next();
            } else {
                console.log(tokens);
                try {
                    let user = await User.findById(tokens.id);
                    res.locals.user = user;
                    next();
                } catch (error) {
                    console.error("Error fetching user:", error);
                    next(error);
                }
            }
        });
    } else {
        res.locals.user = null;
        next();
    }
};

module.exports ={
    authentication, Users
}
