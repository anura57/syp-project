const express = require("express");
const router = express.Router();
const { Signup, Login } = require("../controller/authController");

router.get('/signup', (req, res) => {
    res.render('signup');
});

router.get('/', (req, res) => {
    res.render('home');
});

router.get('/about', (req, res) => {
    res.render('aboutUs');
});

router.get('/contact', (req, res) => {
    res.render('contact');
});

router.get('/course', (req, res) => {
    res.render('course');
});

router.get('/progress', (req, res) => {
    res.render('home');
});


router.post('/signup', Signup);

router.get('/login', (req, res) => {
    res.render('login');
});

router.post('/login', Login);


module.exports = {router:router};
